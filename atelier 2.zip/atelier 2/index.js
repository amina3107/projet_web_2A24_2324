function test(){
    alert('Hello 2A24');return false;
}

console.log("Ceci un test");
let x=prompt("Saisir votre nom","Votre nom");
console.log(typeof(x));
let y=confirm("Voulez vous quitter la salle");
console.log(typeof(y));
let a="Test";
console.log(typeof(a));

var b;
const PI=3.14;